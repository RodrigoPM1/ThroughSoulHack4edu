document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Inicialización de la cámara si estamos en la página de la cámara
    const videoElement = document.getElementById('videoElement');
    if (videoElement) {
        initializeCamera();
    }
});

function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;

    authenticateUser(username, password, role)
        .then(response => {
            if (response.authenticated) {
                redirectToDashboard(role);
            } else {
                alert('Autenticación fallida. Por favor, verifica tus credenciales.');
            }
        })
        .catch(error => {
            console.error('Error durante la autenticación:', error);
            alert('Ocurrió un error durante el inicio de sesión. Por favor, intenta de nuevo.');
        });
}

function authenticateUser(username, password, role) {
    // Simulación de autenticación
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (username && password) {
                resolve({ authenticated: true, role: role });
            } else {
                resolve({ authenticated: false });
            }
        }, 1000);
    });
}

function redirectToDashboard(role) {
    switch(role) {
        case 'alumno':
            window.location.href = 'alumno_dashboard.html';
            break;
        case 'profesor':
            window.location.href = 'profesor_dashboard.html';
            break;
        case 'orientador':
            window.location.href = 'orientador_dashboard.html';
            break;    
        default:
            alert('Rol no reconocido');
    }
}

function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    authenticateUser(username, password)
        .then(response => {
            if (response.authenticated) {
                redirectBasedOnRole();
            } else {
                alert('Autenticación fallida. Por favor, verifica tus credenciales.');
            }
        })
        .catch(error => {
            console.error('Error durante la autenticación:', error);
            alert('Ocurrió un error durante el inicio de sesión. Por favor, intenta de nuevo.');
        });
}

function authenticateUser(username, password) {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (username && password) {
                resolve({ authenticated: true });
            } else {
                resolve({ authenticated: false });
            }
        }, 1000);
    });
}

function redirectBasedOnRole() {
    const roleSelect = document.getElementById('role');
    if (roleSelect) {
        const selectedRole = roleSelect.value;
        switch(selectedRole) {
            case 'alumno':
                window.location.href = 'alumno_dashboard.html';
                break;
            case 'profesor':
                window.location.href = 'profesor_dashboard.html';
                break;
            case 'orientador':
                window.location.href = 'orientador_dashboard.html';
                break; 
            default:
                alert('Por favor, selecciona un rol válido');
        }
    } else {
        console.error('No se encontró el elemento de selección de rol');
    }
}

// Funciones para la cámara
function initializeCamera() {
    const video = document.getElementById('videoElement');
    const canvas = document.getElementById('canvasElement');
    const captureButton = document.getElementById('captureButton');
    const capturedImage = document.getElementById('capturedImage');

    navigator.mediaDevices.getUserMedia({ video: true })
        .then(function(stream) {
            video.srcObject = stream;
        })
        .catch(function(error) {
            console.error("Error al acceder a la cámara: ", error);
        });

    captureButton.addEventListener('click', function() {
        captureImage(video, canvas, capturedImage);
    });
}

function captureImage(video, canvas, capturedImage) {
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    
    const imageDataUrl = canvas.toDataURL('image/jpeg');
    
    capturedImage.src = imageDataUrl;
    capturedImage.style.display = 'block';

    // Aquí podrías enviar la imagen al servidor para análisis de emociones
    // Por ejemplo:
    // sendImageForAnalysis(imageDataUrl);
}

function sendImageForAnalysis(imageData) {
    fetch('/analyze-emotion', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ image: imageData }),
    })
    .then(response => response.json())
    .then(data => {
        console.log('Análisis de emoción:', data);
        // Aquí podrías mostrar los resultados del análisis
    })
    .catch(error => {
        console.error('Error al analizar la imagen:', error);
    });
}

// Datos de ejemplo para las emociones
const datosEmociones = {
    labels: ['0min', '10min', '20min', '30min', '40min', '50min', '60min'],
    datasets: [
        {
            label: 'Feliz',
            data: [65, 70, 80, 75, 85, 90, 88],
            borderColor: 'rgb(255, 99, 132)',
            backgroundColor: 'rgba(255, 99, 132, 0.5)',
        },
        {
            label: 'Triste',
            data: [10, 15, 5, 10, 5, 3, 2],
            borderColor: 'rgb(54, 162, 235)',
            backgroundColor: 'rgba(54, 162, 235, 0.5)',
        },
        {
            label: 'Enfadado',
            data: [5, 10, 8, 12, 6, 3, 5],
            borderColor: 'rgb(255, 206, 86)',
            backgroundColor: 'rgba(255, 206, 86, 0.5)',
        },
        {
            label: 'Sorprendido',
            data: [20, 5, 7, 3, 4, 4, 5],
            borderColor: 'rgb(75, 192, 192)',
            backgroundColor: 'rgba(75, 192, 192, 0.5)',
        },
    ]
};

// Configuración de la gráfica principal
const config = {
    type: 'line',
    data: datosEmociones,
    options: {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: true,
                text: 'Emociones en la Clase'
            }
        },
        onClick: (event, elements) => {
            if (elements.length > 0) {
                const datasetIndex = elements[0].datasetIndex;
                mostrarEvolucionEmocion(datasetIndex);
            }
        }
    },
};

// Crear la gráfica principal
const ctx = document.getElementById('emocionesChart').getContext('2d');
new Chart(ctx, config);

// Función para mostrar la evolución de una emoción específica
function mostrarEvolucionEmocion(datasetIndex) {
    const emocion = datosEmociones.datasets[datasetIndex];
    const evolucionDiv = document.getElementById('evolucionEmocion');

    // Configuración para la gráfica de evolución
    const evolucionConfig = {
        type: 'line',
        data: {
            labels: datosEmociones.labels,
            datasets: [{
                label: emocion.label,
                data: emocion.data,
                borderColor : emocion.borderColor,
                backgroundColor: emocion.backgroundColor,
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: `Evolución de ${emocion.label}`
                }
            }
        }
    };

    // Crear la gráfica de evolución
    const evolucionCtx = document.createElement('canvas').getContext('2d');
    evolucionDiv.innerHTML = ''; // Limpiar el div
    evolucionDiv.appendChild(evolucionCtx.canvas); // Agregar el canvas al div
    new Chart(evolucionCtx, evolucionConfig);
}

// Datos de ejemplo para la gráfica
const emociones = ['Feliz', 'Triste', 'Asustado', 'Sorprendido', 'Enfadado'];
const datos = [40, 20, 15, 10, 15];
const colores = ['#34C759', '#FFC107', '#FF69B4', '#8BC34A', '#E74C3C'];

// Crear la gráfica de barras
constctx = document.getElementById('emocionesChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: emociones,
        datasets: [{
            label: 'Emociones',
            data: datos,
            backgroundColor: colores,
            borderColor: colores,
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});


// Datos de las emociones
constemociones = ['Feliz', 'Triste', 'enfadado', 'Sorprendido', 'Asustado', 'Aburrido', 'Interesado'];
constdatos = [35, 10, 5, 15, 8, 12, 15];
constcolores = [
    '#FFC300', // Feliz - Amarillo
    '#3498DB', // Triste - Azul
    '#E74C3C', // Enojado - Rojo
    '#9B59B6', // Sorprendido - Púrpura
    '#34495E', // Asustado - Gris oscuro
    '#95A5A6', // Aburrido - Gris claro
    '#2ECC71'  // Interesado - Verde
];

// Crear gráfico
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('emocionesChart').getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: emociones,
            datasets: [{
                data: datos,
                backgroundColor: colores,
                borderColor: colores,
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed !== null) {
                                label += context.parsed + '%';
                            }
                            return label;
                        }
                    }
                }
            }
        }
    });

    // Llenar tabla con datos
    const emocionesTable = document.getElementById('emocionesTable');
    emociones.forEach((emocion, index) => {
        const row = emocionesTable.insertRow();
        row.innerHTML = `
            <td>${emocion}</td>
            <td>${datos[index]}%</td>
        `;
    });
});

